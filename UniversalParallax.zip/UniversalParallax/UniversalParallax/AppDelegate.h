//
//  AppDelegate.h
//  UniversalParallax
//
//  Created by Pratik on 27/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

