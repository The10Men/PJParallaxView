//
//  ScrollViewDemoViewController.h
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollViewDemoViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end
