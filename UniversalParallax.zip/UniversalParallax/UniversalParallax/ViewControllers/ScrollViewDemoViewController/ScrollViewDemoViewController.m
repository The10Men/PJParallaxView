//
//  ScrollViewDemoViewController.m
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import "ScrollViewDemoViewController.h"
#import "PJParallaxView.h"
@interface ScrollViewDemoViewController ()
@property PJParallaxView *parallaxView;
@end

@implementation ScrollViewDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 300)];
    imageView.image=[UIImage imageNamed:@"Listing"];
    _parallaxView=[PJParallaxView pj_parallaxViewForTableViewWithHeight:300 viewToStretch:imageView];
    [_scrollView addSubview:_parallaxView];
    _scrollView.contentSize=CGSizeMake([UIScreen mainScreen].bounds.size.width, 1500);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if(scrollView==_scrollView){
        CGPoint offset=scrollView.contentOffset;
        if(scrollView.contentOffset.y>0){
            if(offset.y<0){
                float y = fabs(offset.y);
                y=y-(y-1);
                offset.y=y;
            }
            [_parallaxView layoutHeaderViewReverseForScrollViewOffset:offset];
        }
        else if(scrollView.contentOffset.y<=0){
            [_parallaxView layoutHeaderViewForScrollViewOffset:offset];
        }
    }
}

@end
