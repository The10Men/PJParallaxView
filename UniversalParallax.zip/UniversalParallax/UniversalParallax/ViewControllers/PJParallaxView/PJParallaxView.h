//
//  PJParallaxView.h
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface PJParallaxViewCollectionReusableView : UICollectionReusableView
- (void)initializeDefaultSetupWithView:(UIView*)view;
- (void)layoutHeaderViewForScrollViewOffset:(CGPoint)offset;
- (void)layoutHeaderViewReverseForScrollViewOffset:(CGPoint)offset;
@end

@interface PJParallaxView : UIView
+ (id) pj_parallaxViewForTableViewWithHeight:(CGFloat)height viewToStretch:(UIView*)viewToStretch;
- (void)layoutHeaderViewForScrollViewOffset:(CGPoint)offset;
- (void)layoutHeaderViewReverseForScrollViewOffset:(CGPoint)offset;
@end
