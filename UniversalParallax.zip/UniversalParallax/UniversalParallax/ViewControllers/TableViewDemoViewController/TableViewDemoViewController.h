//
//  TableViewDemoViewController.h
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewDemoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView* tableView;
@end
