//
//  TableViewDemoViewController.m
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import "TableViewDemoViewController.h"
#import "PJParallaxView.h"

@interface TableViewDemoViewController ()<UITableViewDelegate, UITableViewDataSource>
@end

@implementation TableViewDemoViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 300)];
    imageView.image=[UIImage imageNamed:@"Listing"];
    PJParallaxView *parallaxView = [PJParallaxView pj_parallaxViewForTableViewWithHeight:300 viewToStretch:imageView];
    _tableView.tableHeaderView=parallaxView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 30;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.text=@"Demo";
    return cell;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if(scrollView==_tableView){
        CGPoint offset=scrollView.contentOffset;
        if(scrollView.contentOffset.y>0){
            if(offset.y<0){
                float y = fabs(offset.y);
                y=y-(y-1);
                offset.y=y;
            }
            [(PJParallaxView*)_tableView.tableHeaderView layoutHeaderViewReverseForScrollViewOffset:offset];
        }
        else if(scrollView.contentOffset.y<=0){
            [(PJParallaxView*)_tableView.tableHeaderView layoutHeaderViewForScrollViewOffset:offset];
        }
    }
}
@end
