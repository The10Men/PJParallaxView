//
//  CollectionViewDemoViewController.m
//  ParallaxTableHeaderDemo
//
//  Created by Pratik on 26/07/16.
//  Copyright © 2016 PratikJamariya. All rights reserved.
//

#import "CollectionViewDemoViewController.h"
#import "PJParallaxView.h"
@interface CollectionViewDemoViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property UIImageView *imageView;
@end

@implementation CollectionViewDemoViewController
BOOL isParallaxViewAdded;
- (void)viewDidLoad {
    [super viewDidLoad];
    [_collectionView registerClass:[PJParallaxViewCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"PJParallaxViewCollectionReusableView"];
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    _imageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Listing"]];
    _imageView.frame=CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 300);
    _imageView.contentMode=UIViewContentModeScaleAspectFill;
    isParallaxViewAdded=NO;
    [self setAutomaticallyAdjustsScrollViewInsets:NO];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 30;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.backgroundColor=[UIColor colorWithRed:arc4random_uniform(150.0f)/255.0f green:arc4random_uniform(150.0f)/255.0f blue:arc4random_uniform(255.0f)/255.0f alpha:1];
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake([UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.width/2);
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake([UIScreen mainScreen].bounds.size.width, 300);
}

-(UICollectionReusableView*)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        PJParallaxViewCollectionReusableView *parallaxHeader=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"PJParallaxViewCollectionReusableView" forIndexPath:indexPath];
        if(!isParallaxViewAdded){
            [parallaxHeader initializeDefaultSetupWithView:_imageView];
            parallaxHeader.tag=1;
            isParallaxViewAdded=YES;
        }
        return parallaxHeader;
    }
    return nil;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if(scrollView==_collectionView){
        CGPoint offset=scrollView.contentOffset;
        if(scrollView.contentOffset.y>0){
            if(offset.y<0){
                float y = fabs(offset.y);
                y=y-(y-1);
                offset.y=y;
            }
            [[_collectionView viewWithTag:1] layoutHeaderViewReverseForScrollViewOffset:offset];
        }
        else if(scrollView.contentOffset.y<=0){
            
            [[_collectionView viewWithTag:1] layoutHeaderViewForScrollViewOffset:offset];
        }
    }
}

@end
